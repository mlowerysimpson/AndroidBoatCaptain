package com.example.boatcaptain;

import android.content.Context;

public class YesNoDecision {
	void Yes(Context cText) {
		// virtual function, define in subclass

	}

	void No(Context cText) {
		// virtual function, define in subclass

	}
}

